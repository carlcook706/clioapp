<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];
$password = md5($data['password']);



$query = mysqli_query($con, "SELECT * FROM `tbl_users` WHERE `username` = '$username' AND `password` = '$password' ");

$check = mysqli_num_rows($query);

if($check>0) {

    $data = mysqli_fetch_array($query);

    if($data['userTypeID'] == 4){
      $datauser = array(
        'username' => $data['username']
        
      );
    
    http_response_code(201);
    $result = json_encode(array('success'=>true, 'result'=>$datauser));
    }else{
      http_response_code(422);
      $message['status'] = "Application and user account privelege is incorrect";
    }
      
}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);