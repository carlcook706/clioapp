<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$weeklyReportID = $data['weeklyReportID'];
$isApproved = $data['isApproved'];



if($isApproved == 0) {

    
    $query = mysqli_query($con, "UPDATE `tbl_weeklyreport` SET `isApproved`= '1' WHERE weeklyReportID = '$weeklyReportID'");
    
    $query2 = mysqli_query($con, "SELECT * FROM `tbl_weeklyreport` WHERE weeklyReportID = '$weeklyReportID'");
    
    $data2 = mysqli_fetch_array($query2);
    $timeDiff = $data2['timeDiff'];
    $studentNumber = $data2['studentNumber'];
    
    $query3 = mysqli_query($con, "SELECT * FROM `tbl_student` WHERE studentNumber = '$studentNumber'");
    $data3 = mysqli_fetch_array($query3);
    $totalHours = $data3['totalHours'];
    
    $sumTotalHours = $totalHours + $timeDiff;
    
    $query4 = mysqli_query($con, "UPDATE `tbl_student` SET `totalHours`='$sumTotalHours'  WHERE studentNumber = '$studentNumber'");
    
  
    
    
    http_response_code(201);
    $result = json_encode(array('success'=>true));
}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);