<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();


$studentNumber = $data['studentNumber'];
$certificateName = $data['certificateName'];



$query1 = mysqli_query($con, "SELECT * FROM `tbl_certificate` WHERE  studentNumber = '$studentNumber'");

$check = mysqli_num_rows($query1);

if($check<1){
    $query = mysqli_query($con, "INSERT INTO `tbl_certificate`(`studentNumber`, `certificateName`) VALUES ('$studentNumber','$certificateName')");
}else{
     $query = mysqli_query($con, "UPDATE `tbl_certificate` SET `certificateName`=  '$certificateName' WHERE  studentNumber = '$studentNumber'");
}



 
if($query) {
    http_response_code(201);
    $result = json_encode(array('success'=>true));
}else{

    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);