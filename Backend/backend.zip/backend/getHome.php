<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];




$query = mysqli_query($con, "SELECT * FROM `tbl_student` JOIN tbl_users on tbl_users.username = tbl_student.username JOIN tbl_supervisor on tbl_supervisor.studentNumber = tbl_student.studentNumber JOIN tbl_company on tbl_company.id = tbl_supervisor.companyID WHERE tbl_users.username = '$username'");

$check = mysqli_num_rows($query);

if($check>0) {

    $data = mysqli_fetch_array($query);

      $datauser = array(
        'username' => $data['username']
        
      );
    
    http_response_code(201);
    $result = json_encode(array('success'=>true, 'result'=>$datauser));
}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);