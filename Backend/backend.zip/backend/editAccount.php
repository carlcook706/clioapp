<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$username = $data['username'];
$firstName = $data['firstName'];
$middleName = $data['middleName'];
$lastName = $data['lastName'];
$companyName = $data['companyName'];
$contactNumber = $data['contactNumber'];
$password = $data['password'];
$password2 = $data['password'];
$supervisorImage = $data['supervisorImage'];


$query2 = mysqli_query($con, "SELECT * FROM tbl_company JOIN tbl_supervisor on tbl_company.id = tbl_supervisor.companyID JOIN tbl_users on tbl_users.username = tbl_supervisor.username WHERE tbl_supervisor.username  = '$username'");

if($password == ""){
    $data = mysqli_fetch_array($query2);
    $password2 = $data['password'];
}else {
    $password2 = md5($data['password']);
}

$query3 = mysqli_query($con, "SELECT * FROM `tbl_contactnumber`  WHERE contactNumber = '$contactNumber'");

$check3 = mysqli_num_rows($query3);

if($check3<1){
    $query4 = mysqli_query($con, "INSERT INTO `tbl_contactnumber`(`contactNumber`) VALUES ($contactNumber)");
}

$query = mysqli_query($con, "UPDATE `tbl_supervisor`  join tbl_users on tbl_supervisor.username = tbl_users.username SET `supfirstName`= '$firstName',`middleName`='$middleName',`suplastName`='$lastName',`contactID`='$contactNumber',`password`='$password2' ,`supervisorImage`='$supervisorImage' WHERE tbl_users.username = '$username'");
    



if($query) {

    http_response_code(201);

    $data = mysqli_fetch_array($query2);

    $datauser = array(
      'firstName' => $data['supfirstName'],
      'middleName' => $data['middleName'],
      'lastName' => $data['suplastName'],
      'contactNo' => $data['contactID'],
      'companyName' => $data['companyName'],
      'password' => $data['password']

    );
    $result = json_encode(array('success'=>true, 'result'=>$datauser));

}else{
    http_response_code(422);
    $message['status'] = "Error";
}


echo $result;
echo mysqli_error($con);