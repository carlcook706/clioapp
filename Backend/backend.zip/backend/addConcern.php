<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];
$subject = $data['subject'];
$concern = $data['concern'];
$dateTime = $data['dateTime'];
$studentNumber = $data['studentNumber'];
$toUser = $data['toUser'];

if($toUser=="adviser") {
  $query2 = mysqli_query($con, "SELECT tbl_advisers.username FROM `tbl_student` join tbl_advisers on tbl_advisers.sectionID = tbl_student.sectionID WHERE studentNumber= '$studentNumber' and tbl_advisers.batchID = tbl_student.batchID");
  $data2 = mysqli_fetch_array($query2);
  $username1 = $data2['username'];
  
   $query = mysqli_query($con, "INSERT INTO `tbl_rci`(`topic`, `message`, `username`, `rciDateTime`, `isDone`, `toUser`) VALUES ('$subject','$concern','$username','$dateTime',0,'$username1')");
   
   
}else{
   $query = mysqli_query($con, "INSERT INTO `tbl_rci`(`topic`, `message`, `username`, `rciDateTime`, `isDone`, `toUser`) VALUES ('$subject','$concern','$username','$dateTime',0,'$toUser')");
}




if($query) {
    http_response_code(201);
    $result = json_encode(array('success'=>true));
}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);