<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];



$query = mysqli_query($con, "SELECT * FROM tbl_company JOIN tbl_supervisor on tbl_company.id = tbl_supervisor.companyID JOIN tbl_users on tbl_users.username = tbl_supervisor.username WHERE tbl_supervisor.username  = '$username'");

$check = mysqli_num_rows($query);

if($query) {

    $data = mysqli_fetch_array($query);

      $datauser = array(
        'firstName' => $data['supfirstName'],
        'middleName' => $data['middleName'],
        'lastName' => $data['suplastName'],
        'suffix' => $data['suffix'],
        'contactNo' => $data['contactID'],
        'companyName' => $data['companyName']

        
      );
    
    http_response_code(201);
    $result = json_encode(array('success'=>true, 'result'=>$datauser));
}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);