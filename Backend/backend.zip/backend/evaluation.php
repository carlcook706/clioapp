<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];




$query = mysqli_query($con, "SELECT tbl_supervisor.id, tbl_student.studentNumber, tbl_student.firstName, tbl_student.middleName, tbl_student.lastName, tbl_student.suffix FROM tbl_student JOIN tbl_supervisor on tbl_student.supervisorID = tbl_supervisor.id WHERE tbl_supervisor.username = '$username'");



if($query) {

    
    
    $c = 0;

     while($r = mysqli_fetch_assoc($query)) {
   

      $datauser[$c] = array(
          'firstName' => $r['firstName'],
          'middleName' => $r['middleName'],
          'suffix' => $r['suffix'],
          'lastName' => $r['lastName'],
          'studentNumber' => $r['studentNumber'],
          'supervisorID' => $r['id'],
        );
        $c++;
        
  }
    $data = mysqli_fetch_array($query);

    
    http_response_code(201);
    $result = json_encode(array('success'=>true, 'result'=>$datauser));

}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);