<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$weeklyReportID = $data['weeklyReportID'];



$query = mysqli_query($con, "SELECT * FROM tbl_student JOIN tbl_weeklyreport on tbl_student.studentNumber = tbl_weeklyreport.studentNumber WHERE tbl_weeklyreport.weeklyReportID = '$weeklyReportID '");

$check = mysqli_num_rows($query);

if($query) {

    $data = mysqli_fetch_array($query);

      $datauser = array(
        'firstName' => $data['firstName'],
        'middleName' => $data['middleName'],
        'lastName' => $data['lastName'],
        'suffix' => $data['suffix'],
        'date' => $data['date'],
        'timeIn' => $data['timeIn'],
        'timeOut' => $data['timeOut'],
        'tasks' => $data['tasks'],
        'learning' => $data['lesson'],
        'dtrImage' => $data['dtrImage'],
        'isApproved' => $data['isApproved'],
        'studentNumber' => $data['studentNumber']
        
      );
    
    http_response_code(201);
    $result = json_encode(array('success'=>true, 'result'=>$datauser));
}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);