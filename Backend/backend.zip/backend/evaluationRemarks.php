<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];
$remarks = $data['remarks'];
$studentNumber = $data['studentNumber'];
$evaluationForm = $data['evaluationForm'];
$evaluationDate = $data['evaluationDate'];


$query2 = mysqli_query($con, "SELECT * FROM `tbl_supervisor` WHERE tbl_supervisor.username = '$username' ");


$data2 = mysqli_fetch_array($query2);
$supervisorID = $data2['id'];

$query1 = mysqli_query($con, "SELECT * FROM `tbl_evaluation` WHERE  studentNumber = '$studentNumber'");

$check = mysqli_num_rows($query1);

if($check<1){
   $query = mysqli_query($con, "INSERT INTO `tbl_evaluation`(`remarks`, `evaluationForm`, `studentNumber`, `supervisorID`, `evaluationDate`) VALUES ('$remarks','$evaluationForm','$studentNumber','$supervisorID','$evaluationDate')");
}else{
     $query = mysqli_query($con, "UPDATE `tbl_evaluation` SET `remarks`=  '$remarks' , `evaluationForm` = '$evaluationForm', `evaluationDate`  = '$evaluationDate' WHERE  studentNumber = '$studentNumber'");
}

if($query) {
    http_response_code(201);
    $result = json_encode(array('success'=>true));
}else{

    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);