<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);

$studentNumber = $data['studentNumber'];
$fileName = $data['fileName'];
$weekNumber = $data['weekNumber'];



$query1 = mysqli_query($con, "SELECT * FROM `tbl_weekPDFReport` WHERE `weekNumber` = '$weekNumber' and studentNumber = '$studentNumber'");

$check = mysqli_num_rows($query1);

 if($check<1){
 $query = mysqli_query($con, "INSERT INTO `tbl_weekPDFReport` (`weekReportPDFName`,`weekNumber`, `studentNumber`) VALUES ('$fileName', '$weekNumber', '$studentNumber')");
                    }
                    else{
                        
                         $query = mysqli_query($con, "UPDATE `tbl_weekPDFReport` SET `weekReportPDFName`=  '$fileName' WHERE weekNumber = '$weekNumber' and studentNumber = '$studentNumber'");
                    }

