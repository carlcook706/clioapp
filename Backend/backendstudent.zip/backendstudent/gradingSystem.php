<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];

$query = mysqli_query($con, "SELECT * FROM tbl_gradingsystem");

if($query) {
  
    
    $c = 0;

    while($r = mysqli_fetch_assoc($query)) {
     

        $datauser[$c] = array(
            'gradingSystem' => $r
            ['gradingSystem'],
            'criteria' => $r
            ['criteria']
          );
          $c++;
    
    }
 
    
    http_response_code(201);
    
    $result = json_encode(array('success'=>true, 'result'=>$datauser));

}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);
