<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$id = $data['id'];



$query = mysqli_query($con, "SELECT * FROM tbl_docs  WHERE tbl_docs.id = '$id'");
   $data = mysqli_fetch_array($query);
if($query) {
         
         $datauser = array(
        'fileName' => $data['fileName'],
      
      );
    
    http_response_code(201);
    
    $result = json_encode(array('success'=>true, 'result'=>$datauser));

}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);