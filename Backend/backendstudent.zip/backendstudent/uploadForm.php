<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);

$studentNumber = $data['studentNumber'];
$fileName = $data['fileName'];

$fileNameSanitized = str_replace(' ', '', $fileName);

$query = mysqli_query($con, "INSERT INTO `tbl_docs` (`fileName`, `studentNumber`) VALUES ('$fileNameSanitized', '$studentNumber')");