<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];
$lesson = $data['lesson'];
$tasks = $data['tasks'];
$date = $data['date'];
$timeEnd = $data['timeEnd'];
$timeStart = $data['timeStart'];
$dtrImage = $data['dtrImage'];
$weekNumber = $data['weekNumber'];
$studentNumber = $data['studentNumber'];
$dif=array();



$query3 = mysqli_query($con, "SELECT * FROM `tbl_weekNumber` WHERE `weekNumber` = '$weekNumber' and studentNumber = '$studentNumber' ");

$check3 = mysqli_num_rows($query3);


if($check3<1){
    $query4 = mysqli_query($con, "INSERT INTO `tbl_weekNumber`(`weekNumber`, `studentNumber`) VALUES ('$weekNumber','$studentNumber')");
}

$DateTime1 = $timeStart;
$DateTime2   = $timeEnd;

      
            $first = strtotime($DateTime1);
            $second = strtotime($DateTime2);
            $datediff = abs($first - $second);
            $dif['s'] = floor($datediff); 
            $dif['m'] = floor($datediff/(60)); //minute
            $dif['h'] = floor($datediff/(60*60)); //hour
            $dif['d'] = floor($datediff/(60*60*24));//day 
            $dif['M'] = floor($datediff/(60*60*24*30)); //Months
            $dif['y'] = floor($datediff/(60*60*24*30*365));//year
            
            $timeDiff = $dif['h'];
          

$timeStartt = date('h:i:s a', strtotime('+8 hours', strtotime($timeStart)));

$timeEndd = date('h:i:s a', strtotime('+8 hours', strtotime($timeEnd)));




$query = mysqli_query($con, "INSERT INTO `tbl_weeklyreport`( `tasks`, `lesson`, `date`, `studentNumber`, `timeIn`, `timeOut`, `timeDiff`,`dtrImage`,`weekNumber`) VALUES ('$tasks','$lesson','$date','$studentNumber','$timeStartt','$timeEndd','$timeDiff','$dtrImage','$weekNumber')");


   

if($query) {

    http_response_code(201);
    $result = json_encode(array('success'=>true));
}else{
    http_response_code(422);
    $message['status'] = "Error";
}


echo $result;
echo mysqli_error($con);