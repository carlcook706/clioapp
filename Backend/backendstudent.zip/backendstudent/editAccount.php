<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);

$username = $data['username'];
$firstName = $data['firstName'];
$middleName = $data['middleName'];
$lastName = $data['lastName'];
$suffix = $data['suffix'];
$companyName = $data['companyName'];
$password = $data['password'];
$contactNumber = $data['contactNumber'];
$password2 = $data['password'];
$fileName = $data['fileName'];

$query2 = mysqli_query($con, "SELECT * FROM tbl_student JOIN tbl_users on tbl_users.username = tbl_student.username WHERE tbl_student.username  = '$username'");
$data2 = mysqli_fetch_array($query2);
if($password == ""){
    
    $password2 = $data2['password'];
}else {
    $password2 = md5($data['password']);
}


$query3 = mysqli_query($con, "SELECT * FROM `tbl_student` WHERE `contactNumber` = '$contactNumber' ");

$check = mysqli_num_rows($query3);


                     
                    if($check<1){
                       $query4 = mysqli_query($con, "INSERT INTO `tbl_contactnumber`(`contactNumber`) VALUES ($contactNumber)");
                    };

$query = mysqli_query($con, "UPDATE `tbl_student` join tbl_users on tbl_student.username = tbl_users.username SET tbl_student.firstName='$firstName',tbl_student.middleName='$middleName',tbl_student.lastName='$lastName',tbl_student.suffix='$suffix' ,tbl_student.contactNumber='$contactNumber',`password`='$password2',`studentImage`='$fileName' WHERE tbl_student.username = '$username'");



if($query) {

    http_response_code(201);

    $result = json_encode(array('success'=>true));

}else{
    http_response_code(422);
    $message['status'] = "Error";
}


echo $result;
echo mysqli_error($con);