<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$username = $data['username'];
$activity = $data['activity'];
$expectedOutput = $data['expectedOutput'];
$start = $data['start'];
$end = $data['end'];

$query = mysqli_query($con, "INSERT INTO `tbl_calendar` (`activity`, `expectaion`, `calendarID`, `calendarDateTime`, `batchID`) VALUES ('$activity', '$expectedOutput', '$calendarID', '$start', $end)");