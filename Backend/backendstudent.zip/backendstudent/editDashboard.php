<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);

$username = $data['username'];
$companyName = $data['companyName'];
$baranggay = $data['baranggay'];
$street = $data['street'];
$city = $data['city'];
$province = $data['province'];
$supervisorContactNo = $data['supervisorContactNo'];
$supfirstName = $data['supfirstName'];
$middleName = $data['middleName'];
$supLastName = $data['supLastName'];
$id = $data['id'];
$email = $data['email'];
$suffix = $data['suffix'];
$link = $data['link'];
$directions = $data['directions'];
$timeAndDayOfWork = $data['timeAndDayOfWork'];

$postCompanyName = $data['postCompanyName'];
$postBaranggay = $data['postBaranggay'];
$postStreet = $data['postStreet'];
$postCity = $data['postCity'];
$postProvince = $data['postProvince'];
$postContactNo = $data['postContactNo'];
$postSupFirstName = $data['postSupFirstName'];
$postSupLastName = $data['postSupLastName'];
$postEmail = $data['postEmail'];
$postSupSuffix = $data['postSupSuffix'];
$studentNumber = $data['studentNumber'];

$query21 = mysqli_query($con, "SELECT * FROM `tbl_student` WHERE `studentNumber` = '$studentNumber' ");

 $data21 = mysqli_fetch_array($query21);
 
           $postFirstName = $data21['firstName'];
           $postMiddleName = $data21['middleName'];
           $postLastName = $data21['lastName'];
           $postSuffix = $data21['suffix'];
            


$query3 = mysqli_query($con, "SELECT * FROM `tbl_supervisor` WHERE `contactID` = '$supervisorContactNo' ");

$check = mysqli_num_rows($query3);

if($check > 0){
    $query = true;
}else{
    
    $query = mysqli_query($con, "INSERT INTO `tbl_contactnumber`(`contactNumber`) VALUES ('$supervisorContactNo')");
}


if($query) {
    
    
    
    if($id == '2'){
        
        
        $trim = str_replace(' ','',$supLastName); 
        $lower = strtolower($trim);
                    
        $supUsername = $lower.'@clio-rms.com';
        $supPassword = md5($lower.clio);
        
        $query14 = mysqli_query($con, "SELECT * FROM `tbl_users` WHERE `username` = '$supUsername' ");

        $check14 = mysqli_num_rows($query14);
        
        if($check14 > 0){
            
             $query15 = mysqli_query($con, "SELECT `id` FROM `tbl_supervisor` WHERE username = '$supUsername'"); 
         
              $data15 = mysqli_fetch_array($query15);
              $supervisorIDD = $data15['id'];
            
              $query13 = mysqli_query($con, "UPDATE `tbl_student` SET `supervisorID`= $supervisorIDD  WHERE username = '$username'");
        
        }else{
    
        $query5 = mysqli_query($con, "INSERT INTO `tbl_users`(`username`, `password`, `userTypeID`) VALUES ('$supUsername', '$supPassword','4')");
        
       
         $query7 = mysqli_query($con, "INSERT INTO `tbl_address`( `street`, `baranggay`, `city`, `province`, `link`, `directions`) VALUES ('$street','$baranggay','$city','$province','$link','$directions')");  
         
         $query8 = mysqli_query($con, "SELECT `id` FROM `tbl_address` WHERE street = '$street'"); 
         
         $data8 = mysqli_fetch_array($query8);
         $addressID = $data8['id'];
         
         $query9 = mysqli_query($con, "INSERT INTO `tbl_company`(`companyName`, `addressID`) VALUES ('$companyName','$addressID')"); 
         
         $query10 = mysqli_query($con, "SELECT `id` FROM `tbl_company` WHERE companyName = '$companyName' "); 
         
         $data10 = mysqli_fetch_array($query10);
         $companyID = $data10['id'];
         
         $query11 = mysqli_query($con, "INSERT INTO `tbl_supervisor`(`username`, `email`, `supfirstName`, `middleName`, `suplastName`, `suffix`, `contactID`, `companyID`) VALUES ('$supUsername','$email','$supfirstName','$middleName','$supLastName','$suffix','$supervisorContactNo','$companyID')"); 
         
         $query12 = mysqli_query($con, "SELECT `id` FROM `tbl_supervisor` WHERE username = '$supUsername'"); 
         
         $data12 = mysqli_fetch_array($query12);
         $supervisorID = $data12['id'];
         
         
          $query15 = mysqli_query($con, "UPDATE `tbl_student` SET `supervisorID`= $supervisorID  WHERE username = '$username'"); 
          
        }
        
    }else{
        
        $trim = str_replace(' ','',$supLastName); 
        $lower = strtolower($trim);
                    
        $supUsername = $lower.'@clio-rms.com';
        
        $query14 = mysqli_query($con, "SELECT * FROM `tbl_users` WHERE `username` = '$supUsername' ");
        $supPassword = md5($lower.clio);

        $check14 = mysqli_num_rows($query14);
        
        if($check14 > 0){
              $query2 = mysqli_query($con, "UPDATE `tbl_student` JOIN tbl_supervisor on tbl_student.supervisorID = tbl_supervisor.id join tbl_company on tbl_company.id = tbl_supervisor.companyID join tbl_address on tbl_company.addressID = tbl_address.id SET tbl_company.companyName='$companyName', tbl_student.timeAndDayOfWork='$timeAndDayOfWork',tbl_address.street='$street',tbl_address.link='$link',tbl_address.directions='$directions',tbl_address.baranggay='$baranggay',tbl_address.city='$city',tbl_address.province='$province', tbl_supervisor.supfirstName = '$supfirstName',tbl_supervisor.middleName='$middleName',tbl_supervisor.suplastName='$supLastName',tbl_supervisor.contactID='$supervisorContactNo',tbl_supervisor.email='$email',tbl_supervisor.suffix='$suffix' WHERE tbl_student.username = '$username'");
        }else{
            
             $query5 = mysqli_query($con, "INSERT INTO `tbl_users`(`username`, `password`, `userTypeID`) VALUES ('$supUsername', '$supPassword','4')");
        
       
         $query7 = mysqli_query($con, "INSERT INTO `tbl_address`( `street`, `baranggay`, `city`, `province`, `link`, `directions`) VALUES ('$street','$baranggay','$city','$province','$link','$directions')");  
         
         $query8 = mysqli_query($con, "SELECT `id` FROM `tbl_address` WHERE street = '$street'"); 
         
         $data8 = mysqli_fetch_array($query8);
         $addressID = $data8['id'];
         
         $query9 = mysqli_query($con, "INSERT INTO `tbl_company`(`companyName`, `addressID`) VALUES ('$companyName','$addressID')"); 
         
         $query10 = mysqli_query($con, "SELECT `id` FROM `tbl_company` WHERE companyName = '$companyName' "); 
         
         $data10 = mysqli_fetch_array($query10);
         $companyID = $data10['id'];
         
         $query11 = mysqli_query($con, "INSERT INTO `tbl_supervisor`(`username`, `email`, `supfirstName`, `middleName`, `suplastName`, `suffix`, `contactID`, `companyID`) VALUES ('$supUsername','$email','$supfirstName','$middleName','$supLastName','$suffix','$supervisorContactNo','$companyID')"); 
         
         $query12 = mysqli_query($con, "SELECT `id` FROM `tbl_supervisor` WHERE username = '$supUsername'"); 
         
         $data12 = mysqli_fetch_array($query12);
         $supervisorID = $data12['id'];
         
         
          $query15 = mysqli_query($con, "UPDATE `tbl_student` SET `supervisorID`= $supervisorID  WHERE username = '$username'"); 
          
          $query22 = mysqli_query($con, "INSERT INTO `tbl_postcompanyinfo`(`postStudentNumber`, `postFirstName`, `postMiddleName`, `postLastName`, `postSuffix`, `postCompanyName`, `postStreet`, `postBaranggay`, `postCity`, `postProvince`, `postSupFirstName`, `postSupLastName`, `postSupSuffix`, `postContactNo`, `postEmail`) VALUES ('$studentNumber', '$postFirstName','$postMiddleName','$postLastName','$postSuffix','$postCompanyName','$postStreet','$postBaranggay','$postCity','$postProvince','$postSupFirstName','$postSupLastName','$postSupSuffix','$postContactNo','$postEmail')");
            
        }
        
       
    }
    
    http_response_code(201);
    $result = json_encode(array('success'=>true));
    

}else{
    http_response_code(422);
    $message['status'] = "Error";
}


echo $result;
echo mysqli_error($con);