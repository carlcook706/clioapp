<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$studentNumber = $data['studentNumber'];



$query = mysqli_query($con, "SELECT * FROM tbl_weekPDFReport WHERE studentNumber = '$studentNumber' ");

if($query) {
    
    $c = 0;

    while($r = mysqli_fetch_assoc($query)) {
     

        $datauser[$c] = array(
            'fileName' => $r['weekNumber'],
            'id' => $r['id']
          );
          $c++;
    
    }
 
    
    http_response_code(201);
    
    $result = json_encode(array('success'=>true, 'result'=>$datauser));

}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);