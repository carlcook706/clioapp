<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];



$query = mysqli_query($con, "SELECT tbl_student.firstName, tbl_student.suffix, tbl_student.middleName,tbl_student.lastName, tbl_student.contactNumber, tbl_company.companyName , tbl_student.studentImage FROM tbl_student join tbl_supervisor on tbl_student.supervisorID = tbl_supervisor.id join tbl_company on tbl_supervisor.companyID = tbl_company.id  WHERE tbl_student.username = '$username'");



if($query) {

    $data = mysqli_fetch_array($query);

      $datauser = array(
        'firstName' => $data['firstName'],
        'middleName' => $data['middleName'],
        'lastName' => $data['lastName'],
        'suffix' => $data['suffix'],
        'contactNo' => $data['contactNumber'],
        'companyName' => $data['companyName'],
        'studentImage' => $data['studentImage']
      );
    
    http_response_code(201);
    $result = json_encode(array('success'=>true, 'result'=>$datauser));
}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);