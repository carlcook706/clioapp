<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];



$query = mysqli_query($con, "SELECT * FROM tbl_student JOIN tbl_calendar on tbl_student.batchID = tbl_calendar.batchID WHERE tbl_student.username = '$username'");

if($query) {
  

    
    
    $c = 0;

    while($r = mysqli_fetch_assoc($query)) {
     

        $datauser[$c] = array(
            'activity' => $r['activity'],
            'expectation' => $r['expectation'],
            'calendarDateTime' => $r['calendarDateTime']
          );
          $c++;
    
    }
 
    
    http_response_code(201);
    
    $result = json_encode(array('success'=>true, 'result'=>$datauser));

}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);