<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$studentNumber = $data['studentNumber'];

$query = mysqli_query($con, "SELECT * FROM `tbl_weeklyreport` join tbl_student on tbl_student.studentNumber = tbl_weeklyreport.studentNumber WHERE tbl_student.studentNumber = '$studentNumber'");


if($query) {
  
    $c = 0;

    while($r = mysqli_fetch_assoc($query)) {
     

        $datauser[$c] = array(
            'tasks' => $r['tasks'],
            'lesson' => $r['lesson'],
            'date' => $r['date'],
            'comment' => $r['comment'],
            'totalHours' => $r['timeDiff'],
            'timeIn' => $r['timeIn'],
            'timeOut' => $r['timeOut'],
            
          );
         
          $c++;
          
            $datauserr = array(
           'isAbleToRender' => $r['isAbleToRender']
            
          );
    }
 
    
    http_response_code(201);
    
    $result = json_encode(array('success'=>true, 'result'=>$datauser, 'resultt'=>$datauserr));

}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);