<?php
include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];




$query = mysqli_query($con, "SELECT * from tbl_student WHERE tbl_student.username = '$username'");


if($query) {

    $data = mysqli_fetch_array($query);

    $datauser = array(
        'firstName' => $data['firstName'],
        'middleName' => $data['middleName'],
        'lastName' => $data['lastName'],
        'suffix' => $data['suffix'],
        'contactNo' => $data['contactNumber'],
        'studentNumber' => $data['studentNumber']
    );

    http_response_code(201);
    $result = json_encode(array('success' =>true,'result' => $datauser));

}else{
    http_response_code(422);
     $message['status'] = "Error";
     
}

echo $result;
echo mysqli_error($con);