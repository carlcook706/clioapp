<?php

include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input,true);
$message = array();
$username = $data['username'];



$query = mysqli_query($con, "SELECT tbl_student.totalHours, tbl_student.timeAndDayOfWork, tbl_student.totalHoursToRender, tbl_supervisor.email, tbl_company.companyName, tbl_supervisor.suffix, tbl_address.street, tbl_address.baranggay, tbl_address.city, tbl_address.province,tbl_address.link, tbl_address.directions, tbl_supervisor.contactID, tbl_supervisor.supfirstName, tbl_supervisor.middleName, tbl_supervisor.suplastName, tbl_supervisor.contactID , tbl_supervisor.id FROM tbl_student join tbl_supervisor on tbl_student.supervisorID = tbl_supervisor.id join tbl_company on tbl_supervisor.companyID = tbl_company.id join tbl_address on tbl_address.id = tbl_company.addressID WHERE tbl_student.username = '$username'");




if($query) {

    $data = mysqli_fetch_array($query);
    if($data['id'] == '2'){
        $datauser = array(
        'totalHoursToRender' => $data['totalHoursToRender'],
        'ojtHours' => $data['totalHours'],
        'id' => $data['id']
        
      );
        
    }else{
        $datauser = array(
        'totalHoursToRender' => $data['totalHoursToRender'],
        'ojtHours' => $data['totalHours'],
        'companyName' => $data['companyName'],
        'baranggay' => $data['baranggay'],
        'street' => $data['street'],
        'city' => $data['city'],
        'province' => $data['province'],
        'supervisorContactNo' => $data['contactID'],
        'supfirstName' => $data['supfirstName'],
        'middleName' => $data['middleName'],
        'suplastName' => $data['suplastName'],
        'id' => $data['id'],
        'email' => $data['email'],
        'suffix' => $data['suffix'],
        'link' => $data['link'],
        'directions' => $data['directions'],
        'timeAndDayOfWork' => $data['timeAndDayOfWork']
      );
    }
      
    
    http_response_code(201);
    $result = json_encode(array('success'=>true, 'result'=>$datauser));
}else{
    http_response_code(422);
    $message['status'] = "Error";
}

echo $result;
echo mysqli_error($con);